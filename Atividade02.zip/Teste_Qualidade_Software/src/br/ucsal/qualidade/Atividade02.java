package br.ucsal.qualidade;

import java.util.Scanner;

public class Atividade02 {
	
	public static int fatorial(int valor){		
		for(valor = valor; valor > 1; valor--) {
			valor *= valor-1;	
		}
		return valor;

	}
}


