package br.ucsal.qualidade;

import java.io.ByteArrayInputStream;

import org.junit.jupiter.api.Test;

import junit.framework.Assert;

class Teste02 {

	@SuppressWarnings("deprecation")
	@Test
	public void test() {

		//ByteArrayInputStream in = new ByteArrayInputStream("10\n".getBytes());

		//System.setIn(in);

		Atividade02 fat = new Atividade02();
		int resultadoAtual = Atividade02.fatorial(10);
		int resultadoEsperado = 2;
		Assert.assertEquals(resultadoEsperado, resultadoAtual);		
	}
}
